# Download Easy
## Command Line Tool for Download Big or Small Files without worry!
### Why?
* While downloading big files, if downloading stopped for some reason **download-easy will continue to download remaining files not from starting**
* you stop downloading then you can come back and download anytime you from where download left
* Another Great Feature is **while downloading if the internet went off, download-easy wait for internet then It will continue automatically**

### Quick start

```python

  pip install download-easy

  download-easy https://www.sample-videos.com/video123/mp4/720/big_buck_bunny_720p_30mb.mp4


```  
### For More options


```python

  download-easy --help


```  
